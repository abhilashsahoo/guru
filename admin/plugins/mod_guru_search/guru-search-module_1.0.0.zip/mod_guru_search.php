<?php
	require(JModuleHelper::getLayoutPath('mod_guru_search'));
?>